/*
 * Name:        Shida Yang
 * Lab #:       23195
 * Description: This program interfaces with the switches, push buttons,
 *              and LEDs on the Codec board
 */

#include "CodecGPIO.h"

/*
 * Description:
 *      initialize GPIOs used on the Codec board
 * Parameters:
 *      None
 * Return:
 *      None
 */
void initGpio(){
    EALLOW; //enable protective reg write

    //setup GPIO mux registers
    GpioCtrlRegs.GPAMUX1.all=0;
    GpioCtrlRegs.GPAMUX2.all=0;
    GpioCtrlRegs.GPAGMUX1.all=0;
    GpioCtrlRegs.GPAGMUX2.all=0;

    //enable pull-up resistors for inputs
    GpioCtrlRegs.GPAPUD.all=0xFF;

    //set GPIO7:0 as output, GPIO16:14 and GPIO11:8 as input
    GpioCtrlRegs.GPADIR.all=0xFF;

    //turn off LED
    writeToLED(0);
}

/*
 * Description:
 *      read switch value
 * Parameters:
 *      None
 * Return:
 *      Uint16: switch value, SW3:0, up=1, down=0
 */
Uint16 readSwitch(){
    Uint16 sw=GpioDataRegs.GPADAT.all;     //get sw value
    sw=sw&(15<<8);                         //bit mask sw value
    sw=sw>>8;                              //shift sw to position 3:0
    return sw;
}

/*
 * Description:
 *      read PB value
 * Parameters:
 *      None
 * Return:
 *      Uint16: PB value, PB2:0, pressed=1
 */
Uint16 readPB(){
    Uint32 pb=~GpioDataRegs.GPADAT.all;     //get pb value
    pb=pb&((Uint32)7<<14);                  //bit mask pb value
    pb=pb>>14;                      //shift pb to position 2:0
    return pb;
}

/*
 * Description:
 *      output to LED
 * Parameters:
 *      Uint16 data: data to be shown on LEDs,
 *          1=on, 0=off
 * Return:
 *      None
 */
void writeToLED(Uint16 data){
    data=~data;         //revert data bits (because LEDs are active low)
    data=data&0xFF;     //get the lower 8 bits
    GpioDataRegs.GPADAT.all=data;    //output to led
}
