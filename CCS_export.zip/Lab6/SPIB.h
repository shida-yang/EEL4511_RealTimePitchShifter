#include <F28x_Project.h>

void initSpiGpio();
void initSpi();
void setSpiClock(Uint16 clkMHz);
Uint16 send8Bits(Uint16 data);
Uint16 read8Bits();
void writeToSRAM(Uint32 addr, Uint16 data);
void seqWrite(Uint32 startAddr, Uint16* data, Uint32 length);
Uint16 readFromSRAM(Uint32 addr);
Uint16* seqRead(Uint32 startAddr, Uint32 length);
