#include <F2837xD_device.h>

void InitSPIA();
void SpiaTransmit(uint16_t data);
