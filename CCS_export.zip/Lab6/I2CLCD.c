/*
 * Name:        Shida Yang
 * Lab #:       23195
 * Description: This program uses I2C to interface with
 *              the LCD screen.
 */

#include "I2CLCD.h"

//keep track of cursor position
int cursorCounter=0;

/*
 * Description:
 *      Send commands to initialize LCD
 * Parameters:
 *      None
 * Return:
 *      None
 */
void initLCD(){
    //initialize cursor position tracker to 0
    cursorCounter=0;

    //initialize I2C to address 0x27, with 200MHz board clock and 100kHz I2C clock
    I2C_O2O_Master_Init(0x27, 200, 100);

    //create array of LCD initialization commands
    writeCommandReg(0x33);   //Based LED initialization
    writeCommandReg(0x32);   //Based LED initialization
    writeCommandReg(0x28);   //4 Bit mode, 2 Line mode
    writeCommandReg(0x0F);   //Display on, Cursor on, Position on
    writeCommandReg(0x01);   //Clear Screen
    DELAY_US(2000);     //delay after clear screen (need 1.52ms)
}

/*
 * Description:
 *      send a string to LCD
 * Parameters:
 *      char* stringToSend: string to be sent
 * Return:
 *      None
 */
void sendString(char* stringToSend){
    //create pointer to iterate through the string
    char* ptr=stringToSend;
    //while not seeing the terminate character (NULL)
    while(*ptr!=0){
        //write current char
        writeDataReg((Uint16)(*ptr));
        //point to next char
        ptr++;
    }
}

/*
 * Description:
 *      send a string to LCD with automatic line switching
 * Parameters:
 *      char* stringToSend: string to be sent
 * Return:
 *      None
 */
void sendStringAutoSwitch(char* stringToSend){
    //create pointer to iterate through the string
    char* ptr=stringToSend;
    //while not seeing the terminate character (NULL)
    while(*ptr!=0){
        //write current char
        writeDataReg((Uint16)(*ptr));
        //point to next char
        ptr++;
        //increment cursor position tracker
        cursorCounter++;
        //if reach the end of the first line
        if(cursorCounter==16){
            //go to second line
            switchLine();
        }
    }
}

/*
 * Description:
 *      write a command to LCD
 * Parameters:
 *      Uint16 command: command to be written
 * Return:
 *      None
 */
void writeCommandReg(Uint16 command){
    //list of bytes to be sent
    //2 4-bits, each has 3 steps(EL,EH,EL)
    Uint16 I2CInput[6];
    //get lower 4 bits and left-justify
    Uint16 low=(command&0xF)<<4;
    //get higher 4 bits
    Uint16 high=command&0xF0;
    //construct list
    I2CInput[0]=(0x8)|high;       //high EL
    I2CInput[1]=(0xC)|high;     //high EH
    I2CInput[2]=(0x8)|high;     //high EL
    I2CInput[3]=(0x8)|low;      //high EL
    I2CInput[4]=(0xC)|low;      //high EH
    I2CInput[5]=(0x8)|low;      //high EL
    //send command
    I2C_O2O_SendBytes(&I2CInput, 6);
}

/*
 * Description:
 *      write a byte of data to LCD
 * Parameters:
 *      Uint16 data: data to be written
 * Return:
 *      None
 */
void writeDataReg(Uint16 data){
    //list of bytes to be sent
    //2 4-bits, each has 3 steps(EL,EH,EL)
    Uint16 I2CInput[6];
    //get lower 4 bits and left-justify
    Uint16 low=(data&0xF)<<4;
    //get higher 4 bits
    Uint16 high=data&0xF0;
    //construct list
    I2CInput[0]=(0x9)|high;       //high EL
    I2CInput[1]=(0xD)|high;     //high EH
    I2CInput[2]=(0x9)|high;     //high EL
    I2CInput[3]=(0x9)|low;      //high EL
    I2CInput[4]=(0xD)|low;      //high EH
    I2CInput[5]=(0x9)|low;      //high EL
    //send data
    I2C_O2O_SendBytes(&I2CInput, 6);
}

/*
 * Description:
 *      switch cursor to second line
 * Parameters:
 *      None
 * Return:
 *      None
 */
void switchLine(){
    //set DDRAMM addr counter to 0x40
    //which is the first position of the second line
    writeCommandReg(0xC0);
}

/*
 * Description:
 *      clear LCD screen, reset cursor tracker
 * Parameters:
 *      None
 * Return:
 *      None
 */
void clearScreen(){
    writeCommandReg(0x01);   //Clear Screen
    DELAY_US(2000);     //delay after clear screen (need 1.52ms)
    cursorCounter=0;    //reset cursor counter
}
